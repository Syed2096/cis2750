/*
Name: Ahmed Syed
Email: asyed12@uoguelph.ca
Student ID: 1051777
*/

/*Include Libraries*/
#include "VCParser.h"
#include <string.h>
#include <stdlib.h>

/*Define line size*/
#define BUFFER_SIZE 256

/*Create Card Function*/
VCardErrorCode createCard(char* fileName, Card** newCardObject) {

    /*Open file in read mode*/
    FILE *fp = fopen(fileName, "r");
    if(fp == NULL) {

        return INV_FILE;

    }

    /*Initialize loop variables*/
    int i = 0;
    int j = 0;
    int k = 0;

    /*Read file into lines*/
    char oneLine[BUFFER_SIZE];
    char **lines = malloc(sizeof(char*));
    int line = 0;
    lines[line] = malloc(sizeof(char));
    strcpy(lines[line], "");

    while(!feof(fp)) {

        if(fgets(oneLine, BUFFER_SIZE, fp) == NULL) {

            break;

        }

        if(strlen(oneLine) == BUFFER_SIZE - 1) {

            fprintf(stderr, "Error: BUFFER TOO SMALL\n");
            exit(-1);

        }

        lines[line] = realloc(lines[line], strlen(oneLine) + 1);
        strcpy(lines[line], oneLine);
        line++;
        lines = realloc(lines, sizeof(char*) * (line + 1));
        lines[line] = malloc(sizeof(char));
        strcpy(lines[line], "");

    }

    /*Line Unfolding*/
    for(i = 1; i < line; i++) {

        if(lines[i][0] == ' ' || lines[i][0] == '\t') {

            for(j = 0; j < strlen(lines[i - 1]); j++) {
                if(lines[i - 1][j] == '\n' || lines[i - 1][j] == '\r') {
                    lines[i - 1][j] = ' ';
                }
            }

            lines[i - 1] = realloc(lines[i - 1], strlen(lines[i - 1]) + strlen(lines[i]) + 1);
            strncat(lines[i - 1], lines[i], strlen(lines[i]));
            strncpy(lines[i], "", 1);

        }

    }

/*Old attempt at seperating groups, properties, etc*/
/*    fseek(fp, 0, SEEK_SET);

    int word = 0;
    i = 0;
    char **words = malloc(sizeof(char*));
    words[word] = malloc(sizeof(char));
    strcpy(words[word], "");

    while(true) {

        words[word] = realloc(words[word], sizeof(char) * (i + 2));
        words[word][i] = fgetc(fp);
        if(words[word][i] == EOF) {
            break;
        }

        if(words[word][i] == ':' || words[word][i] == ';' || words[word][i] == '=' || words[word][i] == '\n') {
            words[word][i + 1] = '\0';
            //printf("%s\n", words[word]);
            i = 0;
            word++;
            words = realloc(words, sizeof(char*) * (word + 2));
            words[word] = malloc(sizeof(char));
            strcpy(words[word], "");

        } else {

            i++;

        }

    }

    for(i = 0; i < word - 1; i++) {

        if(strcmp(words[i], "http:") == 0 || strcmp(words[i], " http:") == 0) {

            words[i] = realloc(words[i], strlen(words[i]) + strlen(words[i + 1]) + 1);
            strcat(words[i], words[i + 1]);
            strcpy(words[i + 1], "");

        }

    }

    for(i = 0; i < word; i++) {

        if(strcmp(words[i], "FN:") == 0) {

            (*newCardObject) = malloc(sizeof(Card));
            (*newCardObject)->fn = malloc(sizeof(Property));
            (*newCardObject)->fn->name = malloc(sizeof(char) * 5);
            strcpy((*newCardObject)->fn->name, "FN: ");

            if(words[i - 1][strlen(words[i - 1]) - 1] == '.') {
                (*newCardObject)->fn->group = malloc(strlen(words[i - 1]) + 1);
                strcpy((*newCardObject)->fn->group, words[i - 1]);
            } else {
                (*newCardObject)->fn->group = malloc(sizeof(char));
                strncpy((*newCardObject)->fn->group, "", 1);
            }
            (*newCardObject)->fn->parameters = malloc(sizeof(List));
            (*newCardObject)->fn->values = malloc(sizeof(List));
            (*newCardObject)->fn->values->head = malloc(sizeof(Node));
            (*newCardObject)->fn->values->head->data = malloc(strlen(words[i + 1]) + 1);
            strcpy((*newCardObject)->fn->values->head->data, words[i + 1]);

        }

    }

    for(i = 0; i <= word; i++) {
        //printf("%s\n", words[i]);
        free(words[i]);
    }
    free(words);*/

    /*Retun error if card is invalid*/
    if(strstr(lines[0], "BEGIN:VCARD") == NULL || strstr(lines[line - 1], "END:VCARD") == NULL || strstr(lines[1], "VERSION:4.0") == NULL || strstr(lines[2], "FN") == NULL) {
        return INV_CARD;
    }

    /*Initialize Variables for card and counters for parameters and values*/
    int numParam = 0;
    int numValues = 0;
    (*newCardObject) = malloc(sizeof(Card));

    (*newCardObject)->birthday = malloc(sizeof(DateTime));
    (*newCardObject)->birthday->time = malloc(sizeof(char));
    strcpy((*newCardObject)->birthday->time, "");
    (*newCardObject)->birthday->text = malloc(sizeof(char));
    strcpy((*newCardObject)->birthday->text, "");
    (*newCardObject)->birthday->date = malloc(sizeof(char));
    strcpy((*newCardObject)->birthday->date, "");

    (*newCardObject)->anniversary = malloc(sizeof(DateTime));
    (*newCardObject)->anniversary->time = malloc(sizeof(char));
    strcpy((*newCardObject)->anniversary->time, "");
    (*newCardObject)->anniversary->text = malloc(sizeof(char));
    strcpy((*newCardObject)->anniversary->text, "");
    (*newCardObject)->anniversary->date = malloc(sizeof(char));
    strcpy((*newCardObject)->anniversary->date, "");

    (*newCardObject)->optionalProperties = initializeList(propertyToString, deleteProperty, compareProperties);

    /*Loop through lines */
    for(i = 2; i < line - 1; i++) {

        if(strcmp(lines[i], "") == 0) {
            i++;
        }

        /*Seperating into group, name, etc*/
        char* groupName = malloc(sizeof(char));
        checkForGroup(lines[i], &groupName);

        char* propName = malloc(sizeof(char));
        checkForProperty(lines[i], &propName);

        numParam = 0;
        char** parameterNames = malloc(sizeof(char*));
        parameterNames[numParam] = malloc(sizeof(char));
        strcpy(parameterNames[numParam], "");
        checkForParameterNames(lines[i], &parameterNames, &numParam);

        char** parameterValues = malloc(sizeof(char*));
        parameterValues[0] = malloc(sizeof(char));
        strcpy(parameterValues[0], "");
        checkForParameterValues(lines[i], &parameterValues);

        numValues = 0;
        char** values = malloc(sizeof(char*));
        values[numValues] = malloc(sizeof(char));
        strcpy(values[numValues], "");
        checkForValues(lines[i], &values, &numValues);

        /*Build Card*/
        if(strcmp(propName, "FN") == 0) {

            /*Initialize Values*/
            (*newCardObject)->fn = malloc(sizeof(Property));
            (*newCardObject)->fn->group = malloc(strlen(groupName) + 1);
            strcpy((*newCardObject)->fn->group, groupName);
            (*newCardObject)->fn->name = malloc(strlen(propName) + 1);
            strcpy((*newCardObject)->fn->name, propName);
            (*newCardObject)->fn->parameters = initializeList(parameterToString, deleteParameter, compareParameters);
            (*newCardObject)->fn->values = initializeList(valueToString, deleteValue, compareValues);

            /*Loop through parameters*/
            for(j = 0; j < numParam; j++) {

                /*Initialize Values*/
                Parameter* tempParam = malloc(sizeof(Parameter));
                tempParam->name = malloc(strlen(parameterNames[j]) + 1);
                strcpy(tempParam->name, parameterNames[j]);
                tempParam->value = malloc(strlen(parameterValues[j]) + 1);
                strcpy(tempParam->value, parameterValues[j]);

                /*Insert into List*/
                insertBack((*newCardObject)->fn->parameters, tempParam);
            }

            /*Loop through values*/
            for(j = 0; j < numValues; j++) {

                /*Initialize Values*/
                char* tempString = malloc(strlen(values[j]) + 1);
                strcpy(tempString, values[j]);

                /*Insert into List*/
                insertBack((*newCardObject)->fn->values, tempString);
            }

        } else if(strcmp(propName, "BDAY") == 0) {

            /*Check if text*/
            if(strcmp(parameterValues[0], "text") == 0) {
                (*newCardObject)->birthday->isText = true;
                (*newCardObject)->birthday->text = realloc((*newCardObject)->birthday->text, strlen(values[0]) + 1);
                strcpy((*newCardObject)->birthday->text, values[0]);
            } else {

                (*newCardObject)->birthday->isText = false;

                /*Read date*/
                for(j = 0; j < strlen(values[0]); j++) {

                    (*newCardObject)->birthday->date = realloc((*newCardObject)->birthday->date, sizeof(char) * (j + 1));

                    if(values[0][j] == 'T' || values[0][j] == '\n' || j == strlen(values[0]) - 1) {
                        (*newCardObject)->birthday->date[j] = '\0';
                        break;
                    }

                    (*newCardObject)->birthday->date[j] = values[0][j];

                }

                j++;

                /*Read time*/
                for(k = 0; k < strlen(values[0]); k++) {

                    (*newCardObject)->birthday->time = realloc((*newCardObject)->birthday->time, sizeof(char) * (k + 1));
                    if(j >= strlen(values[0])) {
                        (*newCardObject)->anniversary->time[k] = '\0';
                        break;
                    } else if(values[0][j] == 'Z' || values[0][j] == '\n') {
                        (*newCardObject)->birthday->time[k] = '\0';
                        break;
                    }

                    (*newCardObject)->birthday->time[k] = values[0][j];
                    j++;

                }

            }

            /*Check if UTC*/
            if(values[0][strlen(values[0]) - 1] == 'Z') {
                (*newCardObject)->birthday->UTC = true;
            } else {
                (*newCardObject)->birthday->UTC = false;
            }

        } else if(strcmp(propName, "ANNIVERSARY") == 0) {

            if(strcmp(parameterValues[0], "text") == 0) {
                (*newCardObject)->anniversary->isText = true;
                (*newCardObject)->anniversary->text = realloc((*newCardObject)->anniversary->text, strlen(values[0]) + 1);
                strcpy((*newCardObject)->anniversary->text, values[0]);
            } else {

                (*newCardObject)->anniversary->isText = false;
                for(j = 0; j < strlen(values[0]); j++) {

                    (*newCardObject)->anniversary->date = realloc((*newCardObject)->anniversary->date, sizeof(char) * (j + 1));

                    if(values[0][j] == 'T' || values[0][j] == '\n' || j == strlen(values[0]) - 1) {
                        (*newCardObject)->anniversary->date[j] = '\0';
                        break;
                    }

                    (*newCardObject)->anniversary->date[j] = values[0][j];

                }

                for(k = 0; k < strlen(values[0]); k++) {

                    (*newCardObject)->anniversary->time = realloc((*newCardObject)->anniversary->time, sizeof(char) * (k + 1));

                    if(j >= strlen(values[0])) {
                        (*newCardObject)->anniversary->time[k] = '\0';
                        break;
                    } else if(values[0][j] == 'Z' || values[0][j] == '\n') {
                        (*newCardObject)->anniversary->time[k] = '\0';
                        break;
                    }

                    (*newCardObject)->anniversary->time[k] = values[0][j];
                    j++;

                }

            }

            if(values[0][strlen(values[0]) - 1] == 'Z') {
                (*newCardObject)->anniversary->UTC = true;
            } else {
                (*newCardObject)->anniversary->UTC = false;
            }


        } else {

            /*Initialize Variables*/
            Property* tempProp = malloc(sizeof(Property));
            tempProp->group = malloc(strlen(groupName) + 1);
            strcpy(tempProp->group, groupName);
            tempProp->name = malloc(strlen(propName) + 1);
            strcpy(tempProp->name, propName);
            tempProp->parameters = initializeList(parameterToString, deleteParameter, compareParameters);
            tempProp->values = initializeList(valueToString, deleteValue, compareValues);

            /*Loop through Parameters*/
            for(j = 0; j < numParam; j++) {

                /*Initialize Values*/
                Parameter* tempParam = malloc(sizeof(Parameter));
                tempParam->name = malloc(strlen(parameterNames[j]) + 1);
                strcpy(tempParam->name, parameterNames[j]);
                tempParam->value = malloc(strlen(parameterValues[j]) + 1);
                strcpy(tempParam->value, parameterValues[j]);

                /*Insert into List*/
                insertBack(tempProp->parameters, tempParam);
            }

            /*Loop through Values*/
            for(j = 0; j < numValues; j++) {
                char* tempString = malloc(strlen(values[j]) + 1);
                strcpy(tempString, values[j]);
                insertBack(tempProp->values, tempString);
            }

            /*Insert property to list*/
            insertBack((*newCardObject)->optionalProperties, tempProp);

        }

        /*Exit if invalid property*/
        if(strcmp(propName, "") == 0 || numValues == 0) {

            free(groupName);
            free(propName);
            for(j = 0; j <= numParam; j++) {

                free(parameterNames[j]);
            }
            free(parameterNames);
            for(j = 0; j <= numParam; j++) {

                free(parameterValues[j]);
            }
            free(parameterValues);
            for(j = 0; j <= numValues; j++) {

                free(values[j]);
            }
            free(values);

            for(i = 0; i <= line; i++) {
                free(lines[i]);
            }
            free(lines);

            fclose(fp);

            //deleteCard((*newCardObject));
            return INV_PROP;
        }


        /*Free values*/
        free(groupName);
        free(propName);
        for(j = 0; j <= numParam; j++) {

            free(parameterNames[j]);
        }
        free(parameterNames);
        for(j = 0; j <= numParam; j++) {

            free(parameterValues[j]);
        }
        free(parameterValues);
        for(j = 0; j <= numValues; j++) {

            free(values[j]);
        }
        free(values);

    }

    /*Free lines*/
    for(i = 0; i <= line; i++) {
        free(lines[i]);
    }
    free(lines);

    /*Free fp*/
    fclose(fp);

    /*Return value*/
    return OK;

}

/*Delete Card Function*/
void deleteCard(Card* obj) {

    deleteProperty(obj->fn);
    freeList(obj->optionalProperties);
    deleteDate(obj->birthday);
    deleteDate(obj->anniversary);
    free(obj);

}

/*Card to string Function*/
char* cardToString(const Card* obj) {

    /*Read Values*/
    char* FN = propertyToString(obj->fn);
    char* birthday = dateToString(obj->birthday);
    char* anniversary = dateToString(obj->anniversary);
    char* optional = toString(obj->optionalProperties);

    /*Insert into string*/
    char* string = malloc(strlen(FN) + strlen(birthday) + strlen(anniversary) + strlen(optional) + 5);
    strcpy(string, FN);
    strcat(string, birthday);
    strcat(string, "\n");
    strcat(string, anniversary);
    strcat(string, "\n");
    strcat(string, optional);

    /*Free values*/
    free(FN);
    free(birthday);
    free(anniversary);
    free(optional);

    /*Retun string*/
    return string;

}

/*Error to string function*/
char* errorToString(VCardErrorCode err) {

    /*Create string*/
    char* string;

    /*Set string to error*/
    if(err == OK) {
        string = malloc(strlen("OK") + 1);
        strcpy(string, "OK");
    } else if(err == INV_FILE) {
        string = malloc(strlen("INV_FILE") + 1);
        strcpy(string, "INV_FILE");
    } else if(err == INV_CARD) {
        string = malloc(strlen("INV_CARD") + 1);
        strcpy(string, "INV_CARD");
    } else if(err == INV_PROP) {
        string = malloc(strlen("INV_PROP") + 1);
        strcpy(string, "INV_PROP");
    } else if(err == INV_DT) {
        string = malloc(strlen("INV_DT") + 1);
        strcpy(string, "INV_DT");
    } else if(err == WRITE_ERROR) {
        string = malloc(strlen("WRITE_ERROR") + 1);
        strcpy(string, "WRITE_ERROR");
    } else {
        string = malloc(strlen("OTHER_ERROR") + 1);
        strcpy(string, "OTHER_ERROR");
    }

    /*Return string*/
    return string;

}

/*Get groupName*/
void checkForGroup(char* line, char** groupName) {

    int i = 0;
    for(i = 0; i < strlen(line); i++) {

        (*groupName) = realloc((*groupName), sizeof(char) * (i + 1));
        (*groupName)[i] = line[i];

        if(line[i] == ';' || line[i] == ':') {
            strcpy((*groupName), "");
        } else if(line[i] == '.') {
            (*groupName)[i] = '\0';
            break;
        }

    }

}

/*Get propertyName*/
void checkForProperty(char* line, char** propertyName) {

    int i = 0;
    int k = 0;
    for(i = 0; i < strlen(line); i++) {

        (*propertyName) = realloc((*propertyName), sizeof(char) * (k + 1));
        (*propertyName)[k] = line[i];

        if(line[i] == '.') {
            strcpy((*propertyName), "");
            k = -1;
        } else if(line[i] == ';' || line[i] == ':'){
            (*propertyName)[k] = '\0';
            break;
        }

        k++;

    }

}

/*Get parameterNames*/
void checkForParameterNames(char* line, char*** parameterNames, int* numParam) {

    int i = 0;
    int k = 0;
    bool firstColon = false;

    for(i = 0; i < strlen(line); i++) {

        (*parameterNames) = realloc((*parameterNames), sizeof(char*) * ((*numParam) + 2));
        (*parameterNames)[(*numParam)] = realloc((*parameterNames)[(*numParam)], sizeof(char) * (k + 1));
        (*parameterNames)[(*numParam)][k] = line[i];

        if(line[i] == ':') {
            firstColon = true;
        }

        if(firstColon == true) {
            break;
        }

        if(line[i] == ';' || line[i] == ':') {
            strcpy((*parameterNames)[(*numParam)], "");
            k = -1;
        } else if(line[i] == '=') {
            (*parameterNames)[(*numParam)][k] = '\0';
            (*numParam)++;
            (*parameterNames)[(*numParam)] = malloc(sizeof(char));
            strcpy((*parameterNames)[(*numParam)], "");
        }

        k++;

    }

}

/*Get parameterValues*/
void checkForParameterValues(char* line, char*** parameterValues) {

    int i = 0;
    int j = 0;
    int k = 0;
    int elements = 0;
    bool firstColon = false;

    for(i = 0; i < strlen(line); i++) {

        if(line[i] == ':') {
            firstColon = true;
        }

        if(firstColon == true) {
            break;
        }

        if(line[i] == '=') {

            k = 0;

            for(j = i + 1; j < strlen(line); j++) {
                (*parameterValues) = realloc((*parameterValues), sizeof(char*) * (elements + 2));
                (*parameterValues)[elements] = realloc((*parameterValues)[elements], sizeof(char) * (k + 1));
                (*parameterValues)[elements][k] = line[j];

                if(line[j] == ';' || line[j] == ':') {
                    (*parameterValues)[elements][k] = '\0';
                    elements++;
                    (*parameterValues)[elements] = malloc(sizeof(char));
                    strcpy((*parameterValues)[elements], "");
                    break;
                }

                k++;

            }

        }

    }

}

/*Get values*/
void checkForValues(char* line, char*** values, int* numValues) {

    int i = 0;
    int k = 0;
    int j = 0;

    for(i = 0; i < strlen(line); i++) {

        if(line[i] == ':' || line[i] == ';') {

            for(j = i + 1; j < strlen(line); j++) {
                (*values) = realloc((*values), sizeof(char*) * ((*numValues) + 2));
                (*values)[(*numValues)] = realloc((*values)[(*numValues)], sizeof(char) * (k + 2));
                (*values)[(*numValues)][k] = line[j];

                if((line[j] == ':' && line[j + 1] != '/') || (line[j] == '=' && line[j - 3] != 'e')) {
                    k = -1;
                    strcpy((*values)[(*numValues)], "");
                } else if(line[j] == ';' || line[j] == '\n') {
                    (*values)[(*numValues)][k] = '\0';
                    (*numValues)++;
                    (*values)[(*numValues)] = malloc(sizeof(char));
                    strcpy((*values)[(*numValues)], "");
                    k = -1;
                } else if (strlen(line) - 1 == j) {
                    (*values)[(*numValues)][k + 1] = '\0';
                    (*numValues)++;
                    (*values)[(*numValues)] = malloc(sizeof(char));
                    strcpy((*values)[(*numValues)], "");
                    k = -1;
                }

                k++;

            }

            break;

        }

    }

}

/*Delete property Function*/
void deleteProperty(void* toBeDeleted) {

    Property* temp = (Property*) toBeDeleted;

    free(temp->name);
    free(temp->group);
    freeList(temp->parameters);
    freeList(temp->values);
    free(temp);

}

/*Compare properties function*/
int compareProperties(const void* first, const void* second) {
    return 1;
}

/*Property to string Function*/
char* propertyToString(void* prop) {

    Property* temp = (Property*) prop;

    char* group = malloc(strlen(temp->group) + 1);
    strcpy(group, temp->group);
    char* name = malloc(strlen(temp->name) + 1);
    strcpy(name, temp->name);

    char* values = toString(temp->values);
    char* parameters = toString(temp->parameters);

    char* string = malloc(strlen(group) + strlen(name) + strlen(values) + strlen(parameters) + 3);
    strcpy(string, group);
    strcat(string, name);
    strcat(string, parameters);
    strcat(string, values);
    strcat(string, "\n");

    free(group);
    free(name);
    free(values);
    free(parameters);

    return string;
}

/*Delete Parameter Function*/
void deleteParameter(void* toBeDeleted) {

    Parameter* temp = (Parameter*) toBeDeleted;

    free(temp->name);
    free(temp->value);
    free(temp);

}

/*Compare Parameters Function*/
int compareParameters(const void* first, const void* second) {
    return 1;
}

/*Parameter to string Function*/
char* parameterToString(void* param) {

    Parameter* temp = (Parameter*) param;

    char* name = malloc(strlen(temp->name) + 1);
    strcpy(name, temp->name);
    char* value = malloc(strlen(temp->value) + 1);
    strcpy(value, temp->value);

    char* string = malloc(strlen(name) + strlen(value) + 1);
    strcpy(string, name);
    strcat(string, value);

    free(name);
    free(value);

    return string;
}

/*Delete Value Function*/
void deleteValue(void* toBeDeleted) {

    char* value = (char*) toBeDeleted;

    free(value);

}

/*Compare Values Function*/
int compareValues(const void* first, const void* second) {
    return 1;
}

/*Value to string Function*/
char* valueToString(void* val) {

    char* temp = (char*) val;
    char* string = malloc(strlen(temp) + 1);
    strcpy(string, temp);

    return string;
}

/*Delete Date Function*/
void deleteDate(void* toBeDeleted) {

    DateTime* temp = (DateTime*) toBeDeleted;

    free(temp->text);
    free(temp->time);
    free(temp->date);
    free(temp);

}

/*Compare Dates Function*/
int compareDates(const void* first, const void* second) {
    return 1;
}

/*Date to string function*/
char* dateToString(void* date) {

    DateTime* temp = (DateTime*) date;

    char* dateS = malloc(strlen(temp->date) + 1);
    strcpy(dateS, temp->date);
    char* time = malloc(strlen(temp->time) + 1);
    strcpy(time, temp->time);
    char* text = malloc(strlen(temp->text) + 1);
    strcpy(text, temp->text);

    char* string = malloc(strlen(dateS) + strlen(time) + strlen(text) + 1);
    strcpy(string, dateS);
    strcat(string, time);
    strcat(string, text);

    free(dateS);
    free(time);
    free(text);

    return string;
}
