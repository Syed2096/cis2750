/*
Name: Ahmed Syed
Email: asyed12@uoguelph.ca
Student ID: 1051777
*/

/*Include library*/
#include <stdio.h>
#include "VCParser.h"

/*Main*/
int main(int argc, char* argv[])
{

    /*Testing*/
    Card **object = malloc(sizeof(Card*));
    createCard("testCard.vcf", object);
    char* string = cardToString((*object));
    /*printf("%s\n", string);*/
    deleteCard((*object));

    free(string);
    free(object);

    return 0;

}
